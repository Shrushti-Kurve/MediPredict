import React, { useEffect, useState } from "react";
import { FaBell } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { getLoggedInUser } from "../../services/localStorageService";
import { getAlertCount, ackAllAlerts } from "../../services/api/alertService";
import "./NotificationBell.css";

const NotificationBell = () => {

  const user = getLoggedInUser();
  const navigate = useNavigate();

  const [count, setCount] = useState(0);

  const getAlertPage = () => {

    if (!user) return "/";

    if (user.role === "doctor") {
      return "/doctor/alerts";
    }

    if (user.role === "hospitalStaff") {
      return "/hospital/alerts";
    }

    if (user.role === "pharmacist") {
      return "/pharmacist/alerts";
    }

    return "/alerts";
  };

  const loadCount = async () => {

    try {

      try {
        const res = await getAlertCount();
        const c = res?.count || 0;
        setCount(Number(c));
      } catch (e) {
        console.error('Notification count error:', e);
      }

    } catch (error) {

      console.error(
        "Notification count error:",
        error
      );

    }

  };

  useEffect(() => {

    if (!user) return;

    loadCount();

    const interval = setInterval(
      loadCount,
      5000
    );

    return () => clearInterval(interval);

  }, [user?.role]);

  useEffect(() => {
    const handler = () => setCount(0);
    window.addEventListener('alerts:acknowledged', handler);
    return () => window.removeEventListener('alerts:acknowledged', handler);
  }, []);

  if (!user) return null;

  return (

    <button
      className="home-notification-button"
      onClick={async () => {
        // acknowledge alerts so bell clears immediately
        try {
          await ackAllAlerts();
          try { window.dispatchEvent(new CustomEvent('alerts:acknowledged')); } catch (e) {}
        } catch (e) {
          /* ignore */
        }

        setCount(0);
        navigate(getAlertPage());
      }}
      title="View alerts"
    >

      <FaBell />

      {count > 0 && (

        <span className="home-notification-count">
          {count > 99 ? "99+" : count}
        </span>

      )}

    </button>

  );

};

export default NotificationBell;